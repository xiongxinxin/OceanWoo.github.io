

// 1. 卸载gulp命令: sudo npm rm gulp -g
// 2. 安装gulp命令: sudo npm install gulp-cli -g

// 3. 初始化gulp:  sudo npm init
// 4. 开发记录:    sudo npm install gulp --save-dev


