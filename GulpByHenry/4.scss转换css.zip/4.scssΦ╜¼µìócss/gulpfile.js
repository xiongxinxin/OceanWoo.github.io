// 1.引入gulp模块
var gulp = require('gulp');

// 引入gulp-sass模块
var sass = require('gulp-sass');
// 在命令行中输入 gulp bacon

// 2.创建任务
gulp.task("sass",function(){
    return gulp.src("app/scss/style.scss")
    // 找到文件后执行sass转换方法
        .pipe(sass())
        // 指定转换后css文件的存储位置
        .pipe(gulp.dest("app/css"))
})
