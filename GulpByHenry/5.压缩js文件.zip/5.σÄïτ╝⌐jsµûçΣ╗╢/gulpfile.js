
// 通过gulp实现压缩js文件

var gulp = require('gulp');

// 引入压缩js的库模块
var uglify = require('gulp-uglify');

// 引入压缩版的js模块
var rename = require('gulp-rename');

gulp.task("uglify",function () {
    return gulp.src("./app/js/test.js")
        .pipe(uglify())
        .pipe(rename({suffix: '.min'}))
        .pipe(gulp.dest("dist"))
})

// sudo npm install gulp-uglify --save-dev

// sudo npm install gulp-rename --save-dev
