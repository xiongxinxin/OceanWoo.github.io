var name = "Henry";

function worthless() {
    console.log("test how to uglify the js file..");
}
