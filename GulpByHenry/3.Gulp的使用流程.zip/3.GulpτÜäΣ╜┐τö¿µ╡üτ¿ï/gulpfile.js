
// gulpfile.js这个文件告诉gulp工具,具体要做哪些事情.

// gulp使用流程

// 1.引入gulp模块
var gulp = require('gulp');

// 2.告诉gulp去执行某个任务
// gulp.task("task.name",function () {
//     // do something
// });

// gulp.task("bacon",function () {
//     console.log("I love to eat bacon!");
// });

// 在命令行中输入: gulp bacon

gulp.task("girl",function () {
    console.log("Girl is beauty and lovely!");
})
