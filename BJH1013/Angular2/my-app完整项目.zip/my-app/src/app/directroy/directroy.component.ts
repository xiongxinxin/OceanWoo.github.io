import { Component, OnInit } from '@angular/core';
import { LoggingService } from '../logging.service';
import { DataService } from '../data.service';

declare var firebase: any;
@Component({
  selector: 'app-directroy',
  templateUrl: './directroy.component.html',
  styleUrls: ['./directroy.component.css']
})
export class DirectroyComponent implements OnInit {

  people = [];
  constructor(private logger: LoggingService,private dataService:DataService) {}

  logIt(){
    this.logger.log();
  }

  ngOnInit() {
    // this.dataService.fetchData()
    //   .subscribe((data) => this.people = data);

    // 获取firebase中的数据
    this.fbGetData();
  }

  fbGetData(){
    firebase.database().ref('/')
      .on('child_added',(snapshot) => {
        // console.log(snapshot.val());
        this.people.push(snapshot.val());
      })
  }

  fbPostData(name,color){
    firebase.database().ref('/')
      .push({name:name,color:color})
  }

}
