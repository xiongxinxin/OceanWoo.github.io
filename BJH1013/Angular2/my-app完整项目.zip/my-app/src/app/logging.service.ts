import { Injectable } from '@angular/core';

@Injectable()
export class LoggingService {

  // 与数据库链接

  log(){
    console.log('i am logging~~!');
  }

  constructor() { }

}
