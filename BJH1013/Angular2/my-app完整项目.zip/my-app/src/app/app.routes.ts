// 配置路由
import { DirectroyComponent } from './directroy/directroy.component';
import { HomeComponent } from './home/home.component';

import {Routes, RouterModule} from "@angular/router";
import {ModuleWithProviders} from "@angular/core";

// 设置路由路径及组件调用
const appRoutes:Routes = [
  {path:'directory',component:DirectroyComponent},
  {path:'',component:HomeComponent}
];

// 设置路由接口,供app.module.ts使用
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);

