
// 创建一个简单的服务器
var http = require('http');

// 当用户向服务端发送请求时,调用的方法
function onRequest(request,response) {
    // console.log("用户发送了一个请求...",request.url);

    // 处理响应头
    response.writeHead(200,{"Context-Type":"text/plain"});

    // 解决两次请求的方法,把favicon.ico请求干掉
    if (request.url !== "/favicon.ico") {
        console.log("用户发送了一个请求...",request.url);
        response.write("后台给前端返回的数据");
        response.end();
    }
}

// 通过http对象创建服务器
http.createServer(onRequest).listen(8888);

console.log("服务正在启动.....");