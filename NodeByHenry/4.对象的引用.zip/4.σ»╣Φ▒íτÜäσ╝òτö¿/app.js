// 理解Node.js中对象的引用
var Henry = {
    favFood: "bacon",
    favMovie: "湄公河行动"
};

console.log(Henry.favFood); // bacon
console.log(Henry.favMovie); // 湄公河行动

var Person = Henry;

Person.favFood = "Salad";

console.log(Henry.favFood); // bacon or salad

// 对象的引用,会引用内容中相同的对象地址,产生的问题是改变移出,
// 其他引用对象的变量中的属性值,也会同时发生改变