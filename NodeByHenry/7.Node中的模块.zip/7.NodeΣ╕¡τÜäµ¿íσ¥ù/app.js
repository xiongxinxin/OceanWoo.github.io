/**
 * 为了让Node.js的文件可以相互调用,Node.js为我们提供了一种机制 --- 模块系统
 *
 * Node.js中的每一个文件都代表一个模块,文件的类型是js / json数据格式等
 * */

// Node中的模块(module)

var movies = require("./movie");

// 通过movies对象调用movie.js中的方法
movies.printHenry();
movies.wendy();

