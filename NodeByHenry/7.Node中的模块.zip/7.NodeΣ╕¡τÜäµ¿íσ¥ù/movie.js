function printHenry() {
    console.log("Henry最喜欢的电影是湄公河行动");
}

function printWendy() {
    console.log("Wendy最喜欢的电影是机械师2");
}

module.exports.printHenry = printHenry;
module.exports.wendy = printWendy;


// 视频外的解释
var obj = {};  //== module.exports

obj.printHenry = printHenry;

obj.printHenry();

// 问题: 如果有多个函数,那么需要使用对应数量的module.exports指定方法名.
