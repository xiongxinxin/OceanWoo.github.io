
module.exports = {
    printHenry: function () {
        console.log("Henry最喜欢的电影是肖申克救赎");
    },
    printWendy: function () {
        console.log("Wendy最喜欢的电影是美丽人生");
    },
    favMovie: "前端生涯的开始到放弃"
};