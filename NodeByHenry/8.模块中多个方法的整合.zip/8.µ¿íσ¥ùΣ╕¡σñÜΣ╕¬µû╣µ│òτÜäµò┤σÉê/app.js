
// 模块中多个方法的整合

// 引入对应的模块
var movie = require("./movie");

// 调用方法
movie.printHenry();
movie.printWendy();
console.log(movie.favMovie);