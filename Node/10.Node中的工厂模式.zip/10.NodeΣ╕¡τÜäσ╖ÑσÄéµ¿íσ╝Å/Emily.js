// 引入movie模块
var Emily = require("./movie");

var Wendy = Emily();

console.log(Wendy.favMovie);
