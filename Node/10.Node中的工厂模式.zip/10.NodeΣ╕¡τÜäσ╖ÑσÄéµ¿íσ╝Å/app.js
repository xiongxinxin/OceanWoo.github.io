
// 工厂模式

require("./Bucky");
require("./Emily");

