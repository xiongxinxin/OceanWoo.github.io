module.exports = function () {
    return {
        favMovie: ""
    };
};

