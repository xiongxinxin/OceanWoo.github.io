// 引入movie.js模块
var Bucky = require("./movie");

var Henry = Bucky();

Henry.favMovie = "机械师2";
console.log(Henry.favMovie);

