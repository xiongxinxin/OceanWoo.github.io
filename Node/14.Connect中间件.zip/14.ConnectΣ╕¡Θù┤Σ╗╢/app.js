
// Connect中间件
var connect = require('connect');

// 创建一个服务器
var http = require("http");

var app = connect();

// function doFirst(request,response,next) {
//     console.log("first");
//     next();
// }
//
// function doSecond(request,response) {
//     console.log("second");
// }
//
// app.use(doFirst);
// app.use(doSecond);

function about(request,response,next) {
    console.log("用户请求的网页是about.html");

}

function profile(request,response,next) {
    console.log("用户请求的网页是profile.html");
}

app.use("/about",about);
app.use("/profile",profile);


http.createServer(app).listen(8888);

console.log("Server is now running....");