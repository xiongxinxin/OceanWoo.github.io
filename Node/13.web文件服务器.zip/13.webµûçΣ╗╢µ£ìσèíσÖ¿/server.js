
// web文件服务器示例
var http = require('http');
var fs = require('fs');

function send404Request(response) {
    response.writeHead(404,{"Context-Type":"text/plain"});
    response.write("error 404: page not found!");
    response.end();
}

function onRequest(request,response) {
    if (request.url !== "/favicon.ico") {
        if (request.method == "GET" && request.url == "/"){
            response.writeHead(200, {"Context-Type": "text/html"});
            // fs.createReadStream("要读取文件的路径.文件后缀").pipe(response);
            fs.createReadStream("./index.html").pipe(response);
        }else{
            send404Request(response);
        }
    }
}

http.createServer(onRequest).listen(8888);
console.log("Server is now running....");