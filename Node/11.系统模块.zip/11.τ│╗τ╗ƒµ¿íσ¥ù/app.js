
// Node中的核心模块 / 系统模块

// fs : file system
// var fs = require('fs');
//
// // 写入文件
// // fs.writeFileSync("文件名.文件类型","文件中承载的内容");
// fs.writeFileSync("ChickenSoup.txt","不以物喜,不以己悲!");
//
// // 读取文件
// console.log(fs.readFileSync("ChickenSoup.txt").toString());


// path
var path = require('path');
var websiteHome = "Desktop//React//index.html";
var websiteLogin = "Desktop/React/login.html";

console.log(path.normalize(websiteHome)); // 正确完整的路径
console.log(path.dirname(websiteLogin)); // Login文件上面所有的路径
console.log(path.basename(websiteLogin)); // 获取Login文件名及后缀文件类型
console.log(path.extname(websiteLogin)); // 获取Login文件后缀名

// 对于路径来讲,还有两个对应的全局对象
console.log(__dirname);  // 当前文件以上的路径
console.log(__filename); // 当前文件的完整路径
