// 引入movie.js模块
var Bucky = require("./movie");

Bucky.favMovie = "湄公河行动";

console.log(Bucky.favMovie); // 湄公河行动

