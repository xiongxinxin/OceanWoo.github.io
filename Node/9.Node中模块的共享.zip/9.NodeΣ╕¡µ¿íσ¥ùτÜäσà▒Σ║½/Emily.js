// 引入movie模块
var Emily = require("./movie");

console.log(Emily.favMovie); // undefined
