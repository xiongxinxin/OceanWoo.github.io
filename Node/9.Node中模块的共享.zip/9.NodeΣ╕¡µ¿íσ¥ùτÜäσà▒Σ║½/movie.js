module.exports = {
    favMovie: ""
};