// console.log('bacon');

// node.js前的铺垫 -- basic concepts基本概念

// 复习对象
var person = {
    firstName: "jiaojiao",
    lastName: "gao",
    age: 28
};

console.log(person);

// 复习函数
function addNumber(a,b) {
    return a + b;
}

console.log(addNumber(7,3));

// 查看函数的默认返回值
function  worthless() {

}

console.log(worthless()); // undefined

// 匿名函数
var printBacon = function () {
    console.log("在创建函数时,没有指定函数名!");
}

printBacon();

// 定时器,倒计时5秒后再次执行此函数
setTimeout(printBacon,5000);



