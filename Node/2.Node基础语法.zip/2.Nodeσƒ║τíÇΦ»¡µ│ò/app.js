
// 使用回调函数处理多个请求,并保证线程不堵塞
function placeAndOrder(orderNumber) {
    console.log("这是第"+orderNumber+"个,看病的病人.")

    checkAndDeliverPatient(function () {
        console.log("第"+orderNumber+"个病人,已经看完病了.");
    })
}

function checkAndDeliverPatient(callback) {
    setTimeout(callback,5000);
}

placeAndOrder(1);
placeAndOrder(2);
placeAndOrder(3);
placeAndOrder(4);
placeAndOrder(5);
placeAndOrder(6);
