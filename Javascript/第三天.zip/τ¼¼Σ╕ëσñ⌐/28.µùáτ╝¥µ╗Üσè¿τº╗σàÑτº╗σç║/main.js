
function rollFn(){
	// 获取元素对象
	var wrap = document.getElementById("wrap");
	var roll = document.getElementById("roll");
	var imgs = roll.getElementsByTagName('img');

	var step = 0;
	var width = imgs[0].offsetWidth * imgs.length;

	var timer = null;


	// 自动滚动
	function rollAuto(){
		// 定时器
		timer = setInterval(function(){

			move();

		},30);
	}

	// 动起来的方法
	function move(){
		step -= 5;
		if (step <= -width) {
			step = 0;
		}
		roll.style.left = step + 'px';		
	}

	// 鼠标移入 移除的方法
	function bind(){
		wrap.onmouseover = function(){
			clear();
		}

		wrap.onmouseout = function(){
			rollAuto();
		}
	}

	// 清除定时器
	function clear(){
		clearInterval(timer);
		timer = null;
	}


	// 初始化
	function init(){
		roll.innerHTML += roll.innerHTML;
		rollAuto();
		bind();
	}

	init();
}

rollFn();