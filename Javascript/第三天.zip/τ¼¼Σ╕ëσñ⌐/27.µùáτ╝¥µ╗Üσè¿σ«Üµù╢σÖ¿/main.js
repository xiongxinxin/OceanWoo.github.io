
function rollFn(){
	// 获取元素对象
	var wrap = document.getElementById("wrap");
	var roll = document.getElementById("roll");
	var imgs = roll.getElementsByTagName('img');

	var step = 0;
	var width = imgs[0].offsetWidth * imgs.length;

	// 自动滚动
	function rollAuto(){
		// 定时器
		setInterval(function(){

			move();

		},30);
	}

	// 动起来的方法
	function move(){
		step -= 5;
		if (step <= -width) {
			step = 0;
		}

		roll.style.left = step + 'px';		
	}

	// 初始化
	function init(){
		roll.innerHTML += roll.innerHTML;
		rollAuto();
	}

	init();
}

rollFn();