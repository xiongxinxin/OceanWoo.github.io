
function imgScroll(){

	// 获取元素对象
	var btnMod = document.querySelector(".btn_mod");
	var imgMod = document.querySelector(".img_mod");
	var scrollMod = imgMod.querySelector(".scroll");
	var imgs = imgMod.querySelectorAll("img");
	var btns = document.querySelectorAll(".btn_list li");

	var timer = null;
	var activeIndex = 0;
	var maxLength = imgs.length;
	var width = imgs[0].offsetWidth;

	function autoSwitch(){
		timer = setInterval(function(){
			// 下一页
			nextFn();
		},3000);
	}

	// 下一页
	function nextFn(){
		activeIndex = activeIndex >= maxLength - 1 ? 0 : ++activeIndex;
		switchTo(activeIndex);
	}

	// 切换到指定索引的位置方法
	function switchTo(index){
		scrollMod.style.left = -width * index + "px";

		for (var i = 0; i < btns.length; i++) {
			btns[i].className = "";
		}

		// 让对应图片下标的按钮,拥有激活状态类名
		btns[index].className = "active";
	}

	function init(){
		autoSwitch();
	}

	init();
}

imgScroll();