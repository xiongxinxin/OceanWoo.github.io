
function imgScroll(){

	// 获取元素对象
	var btnMod = document.querySelector(".btn_mod");
	var imgMod = document.querySelector(".img_mod");
	var scrollMod = imgMod.querySelector(".scroll");
	var imgs = imgMod.querySelectorAll("img");
	var btns = document.querySelectorAll(".btn_list li");

	var timer = null;
	var activeIndex = 0;
	var maxLength = imgs.length;
	var width = imgs[0].offsetWidth;

	function autoSwitch(){
		timer = setInterval(function(){
			// 下一页
			nextFn();
		},3000);
	}

	// 下一页
	function nextFn(){
		activeIndex = activeIndex >= maxLength - 1 ? 0 : ++activeIndex;
		switchTo(activeIndex);
	}

	// 切换到指定索引的位置方法
	function switchTo(index){
		scrollMod.style.left = -width * index + "px";

		for (var i = 0; i < btns.length; i++) {
			btns[i].className = "";
		}

		// 让对应图片下标的按钮,拥有激活状态类名
		console.log(index);
		btns[index].className = "active";
	}

	// 总的事件函数
	function bind(){
		// 下一页
		var next = document.querySelector(".next");
		var prev = document.querySelector(".prev");

		next.onclick = function(){
			nextFn();
		}

		// 上一页
		prev.onclick = function(){
			prevFn();
		}

		// 鼠标的一些事件
		btnMod.onmouseover = function(){
			clear();
		}

		btnMod.onmouseout = function(){
			autoSwitch();
		}

		imgMod.onmouseover = function(){
			clear();
		}

		imgMod.onmouseout = function(){
			autoSwitch();
		}

		// 为每个li添加点击事件
		for(var i = 0;i < btns.length; i++){
			btns[i].onclick = (function(index){
				return function(){
					switchTo(index);
				}
			})(i)
		}
	}

	// 上一页的具体方法
	function prevFn(){
		activeIndex = activeIndex <= 0 ? maxLength - 1 : --activeIndex;
		switchTo(activeIndex);
	}

	function clear(){
		clearInterval(timer);
		timer = null;
	}

	function init(){
		autoSwitch();

		bind();
	}

	init();
}

imgScroll();