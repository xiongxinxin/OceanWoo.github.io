import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { SettingsService } from '../services/settings.service';

@Injectable()
export class RegisterGuard implements CanActivate {

  constructor(
      public router:Router,
      public settingsService:SettingsService
      ) { }

  canActivate(): boolean{
    if (this.settingsService.getSettings().allowRegistration) {
      return true;
    }else{
      this.router.navigate(["/login"]);
      return false;
    }
  }
}
