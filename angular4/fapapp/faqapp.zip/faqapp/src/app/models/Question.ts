export interface Question{
	text:string,
	answer:string,
	hide:boolean
}